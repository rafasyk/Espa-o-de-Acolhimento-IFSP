<?php
session_start();
require "../../conexao.php";

$protocolo = $_GET["protocolo"];

$sql= "UPDATE denuncias SET Aprovado = 1 WHERE id = $protocolo";

$result= mysqli_query($conexao, $sql);


if($result) {
    header('Location: ../../denuncias.php');
} else {
    echo "Não foi possível realizar a edição ";
    echo "<a href='../index.php'>Voltar a página inicial</a>";
    echo mysqli_error($conexao);
}