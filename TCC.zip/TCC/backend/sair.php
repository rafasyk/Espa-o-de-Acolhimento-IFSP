<?php 
require "../conexao.php";

$id = $_GET['id'];

$id = intval($id);

$sql = "DELETE FROM socio WHERE id = $id";
$result = mysqli_query($conexao, $sql);

if ($result) {
    header('Location: ../acolhimento.php');
    exit();
} else {
    echo "Não foi possível excluir o perfil ";
    echo "<a href='../index.php'>Voltar à página inicial</a>";
    echo mysqli_error($conexao);
}
?>
