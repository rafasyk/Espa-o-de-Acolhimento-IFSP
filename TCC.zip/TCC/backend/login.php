<?php 

require "../conexao.php";
session_start();

if(isset($_POST['login']) && !empty($_POST['usuario']) && !empty($_POST['senha'])){

    $usuario = $_POST["usuario"];
    $senha = $_POST["senha"];


    $select = "SELECT * from socio WHERE nome ='$usuario' and password='$senha'";

    $resul = mysqli_query($conexao, $select);
    

    $linha = mysqli_fetch_assoc($resul);

    $_SESSION["senha"] = $senha;
    $_SESSION["usuario"] = $usuario;
    $_SESSION["id"] = $linha["id"];
    
    header("location: ../tratamento.php");
   
}