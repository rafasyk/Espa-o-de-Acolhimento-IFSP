<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro de Denúncia - IFSP Itapetininga</title>
    <link href="../../css/bootstrap.min.css" rel="stylesheet">
    <link href="../../css/style.css" rel="stylesheet">

    <style>
    body {
            background-color: #8f9287;
            font-family: Arial, sans-serif;
        }

        .container {
            padding-top: 5%;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .card {
            background-color: white;
            width: 400px;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        .card h1 {
            font-size: 1.3em;
            text-align: center;
            color: #4CAF50;
            margin-bottom: 30px;
        }

        .card img {
            display: block;
            margin: 0 auto 20px;
        }

        .btn {
            width: 100%;
            padding: 10px;
            font-size: 16px;
        }


        .links {
            margin-top: 20px;
            text-align: center;
        }

        .links a {
            color: #4CAF50;
            text-decoration: none;
        }

        .links a:hover {
            text-decoration: underline;
        }

    </style>    
</head>
<body>
    <div class="container">
    <div class="card">
        <h1>CADASTRO SÓCIOPEDAGÓGICO</h1>
        <form action="cadastro.php" method="post" enctype="multipart/form-data">
        <div class="form-box">
        <div class="form-group">
        
        
        <label for="photo">Selecione suas fotos:</label>
        <input type="file" name="photo" id="fotos" multiple>
    <p></p>

            <label style="margin-left: 37px;"for="nome">Nome completo:</label>
            <input style="margin-left: 37px; border-radius: 10px; height: 30px;width: 250px"type="text" name="nome">
            <br>
        </div>
            <div class="form-group">
            <label style="margin-left: 37px;"for="nome">Prontuário:</label>
            <input style="margin-left: 37px; border-radius: 10px; height: 30px;width: 250px"type="text" name="prontuario">
            <div class="form-group">
            <label style="margin-left: 37px;"for="senha">Senha:</label>
            <input style="margin-left: 37px;border-radius: 10px; height: 30px;width: 250px;"type="password" name="senha">
            <br>
            <p></p>
            <button style="margin-left: 64px;border-radius: 10px; height: 40px;width: 200px;"class="botao">CADASTRAR</button>
            </div>
            </div>
        </form>
        <div class="links">      
        <a style="margin-left: 20px;"href="../../index.html">Voltar para a página inicial</a>
    </div>
    </div>
  </div>
</div>
</body>
</html>