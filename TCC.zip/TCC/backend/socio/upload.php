<?php
require "C:/Users/rafae/Desktop/TCC/TCC/conexao.php";

$nome = $_POST['nome'];
$senha = $_POST["senha"];
$photo_name = $_FILES['photo']['name'];
$photo_tmp_name = $_FILES['photo']['tmp_name'];
$upload_dir = "../../uploads/";

if (move_uploaded_file($photo_tmp_name, $upload_dir . $photo_name)) {
    $sql = "INSERT INTO socio (nome, password, photo) VALUES ('$nome', '$senha', '$photo_name')";
    $result = mysqli_query($conexao, $sql);

    if ($result) {
        header('Location: ../../socios.php');
    } else {
        echo "Não foi possível realizar o cadastro ";
        echo "<a href='../index.php'>Voltar a página inicial</a>";
        echo mysqli_error($conexao);
    }
} else {
    echo "Falha no upload da foto.";
}

?>

