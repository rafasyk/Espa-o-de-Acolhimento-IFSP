<?php
session_start();

?>
<!DOCTYPE html>
<html prefix="og: http://ogp.me/ns#" class="no-js" lang="pt-br" dir="ltr">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">

	<link href="css/banner-rotativo-home.css" rel="stylesheet" type="text/css">

	<link href="css/bootstrap.min.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="css/enEKLtB6eJV.css" type="text/css">
	
	<link href="css/fontawesome/css/all.min.css" rel="stylesheet" />

	<link href="css/fontes.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="css/icones-bmp-verde.css" type="text/css">

	<link href="css/k2.css" rel="stylesheet" type="text/css">

	<link rel="stylesheet" href="css/template-verde.css" type="text/css">
	
	
	
	

	<link rel="stylesheet" href="css/style.css">

	<title>Portal ITP - IFSP - Página inicial</title>
	<link href="https://itp.ifsp.edu.br/templates/padraogoverno01/favicon.ico" rel="shortcut icon"
		type="image/vnd.microsoft.icon">
	<link href="https://itp.ifsp.edu.br/index.php/component/search/?Itemid=101&amp;format=opensearch" rel="search"
		title="Buscar Portal ITP - IFSP" type="application/opensearchdescription+xml">
	
	<script src="./Portal ITP - IFSP - Página inicial_files/k2.js.download" type="text/javascript"></script>
	<script src="./Portal ITP - IFSP - Página inicial_files/bootstrap.min.js.download" type="text/javascript"></script>

	<meta content="width=device-width, initial-scale=1.0" name="viewport">
	<style>
		.dados {
			text-align: center;
			font-size: 26px;
			font-weight: bold;
		}

		label {
			margin-top: 50px;
			font-weight: bold;
			font-size: 20px;
			text-align: left;
			margin-bottom: 10px	;
		}

		#protocolo {
			text-align: left;
			height: 60px;
			border-radius: 10px;
			width: 100%;
			margin-bottom: 20px;
		}
		.box {
			box-sizing: border-box;
			background-color: #e5e5e5;
    border-radius: 1em;
    padding: 8px;
    border: 2px solid black;
		}
		
	</style>
</head>

<body>
	<noscript>
		<div class="error minor-font">
			Seu navegador de internet está sem suporte à JavaScript. Por esse motivo algumas funcionalidades do site
			podem não estar acessíveis.
		</div>
	</noscript>

	<div class="layout">
		<header>
			<div class="container">
				<div class="row-fluid accessibility-language-actions-container">
					<div class="span6 accessibility-container">
						<ul id="accessibility">
							<li>
								<a accesskey="1" href="https://itp.ifsp.edu.br/#content" id="link-conteudo">
									Ir para o conteúdo
									<span>1</span>
								</a>
							</li>
							<li>
								<a accesskey="2" href="https://itp.ifsp.edu.br/#navigation" id="link-navegacao">
									Ir para o menu
									<span>2</span>
								</a>
							</li>
							<li>
								<a accesskey="3" href="https://itp.ifsp.edu.br/#portal-searchbox" id="link-buscar">
									Ir para a busca
									<span>3</span>
								</a>
							</li>
							<li>
								<a accesskey="4" href="https://itp.ifsp.edu.br/#footer" id="link-rodape">
									Ir para o rodapé
									<span>4</span>
								</a>
							</li>
						</ul>
					</div>
					<div class="span6 language-and-actions-container">
						<h2 class="hide">Opções de acessibilidade</h2>

						<ul class="pull-right" id="portal-siteactions">
							<li class="item-140"><a href="https://itp.ifsp.edu.br/index.php/acessibilidade"
									accesskey="5">Acessibilidade</a></li>
							<li class="item-141 toggle-contraste"><a class="toggle-contraste"
									href="https://itp.ifsp.edu.br/#" accesskey="6">Alto contraste</a></li>
							<li class="item-142"><a href="https://itp.ifsp.edu.br/index.php/mapa-do-site"
									accesskey="7">Mapa do site</a></li>
						</ul>

					</div>
				</div>
				<div class="row-fluid">
					<div id="logo" class="span8 small">
						<a href="index.html" title="Campus Itapetininga">
							<span class="portal-title-1">Instituto Federal de São Paulo</span>
							<h1 class="portal-title corto">Campus Itapetininga</h1>
							<span class="portal-description">Ministério da Educação</span>
						</a>
					</div>
					<div class="span4">
						<div id="portal-searchbox" class="row">
							<h2 class="hidden">Buscar no portal</h2>
							<form action="https://itp.ifsp.edu.br/index.php" method="post" class="pull-right">
								<fieldset>
									<legend class="hide">Busca</legend>
									<h2 class="hidden">Buscar no portal</h2>
									<div class="input-append">
										<label for="portal-searchbox-field" class="hide">Busca: </label>
										<input type="text" id="portal-searchbox-field" class="searchField"
											placeholder="Buscar no portal" title="Buscar no portal" name="searchword">
										<button type="submit" class="btn searchButton"><span
												class="hide">Buscar</span><i class="fa-solid fa-search"></i></button>
									</div>
									<input type="hidden" name="task" value="search">
									<input type="hidden" name="option" value="com_search">
									<input type="hidden" name="Itemid" value="101">
								</fieldset>
							</form>
						</div>
						<div id="social-icons" class="row">
							<h2 class="hidden">Redes Sociais</h2>

							<ul class="pull-right">
								<li class="portalredes-item item-138"><a href="https://www.facebook.com/ifspitape/"
										target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-square-facebook"></i><span>Facebook</span></i></a></li>
								<li class="portalredes-item item-257"><a
										href="https://www.instagram.com/ifspitapetininga/" target="_blank"
										rel="noopener noreferrer"><i class="fa-brands fa-square-instagram"></i></a></li>
								<li class="portalredes-item item-137"><a
										href="https://www.youtube.com/channel/UCEMUJSUnnvmrRQoD28-iGbQ/videos"
										target="_blank" rel="noopener noreferrer"><i class="fa-brands fa-square-youtube"></i></a></li>
							</ul>
						</div>

					</div>
				</div>
			</div>
			<div class="sobre">
				<div class="container">
					<nav class="menu-servicos pull-right">
						<h2 class="hide">Serviços</h2>

						<ul>
							<li class="item-888"><a href="acolhimento.php"
								rel="noopener noreferrer">Espaço de acolhimento</a></li>
							<div>
								<li class="item-132 parent"><a
										href="https://itp.ifsp.edu.br/index.php/contato-e-localizacao">Contato </a></li>
								<li class="item-463"><a href="https://itp.ifsp.edu.br/index.php/localizacao">Localização</a>
								</li>
								<li class="item-264"><a href="http://www.ifsp.edu.br/ouvidoria/" target="_blank"
										rel="noopener noreferrer">Ouvidoria</a></li>
								<li class="item-497"><a href="https://www.ifsp.edu.br/acessoainformacao" target="_blank"
										rel="noopener noreferrer">Acesso à Informação</a></li>
							</div>
						<span class="hide">Fim do menu de serviços</span>
					</nav>

				</div>
				<!-- .container -->
			</div>
			<!-- fim .sobre -->
		</header>
		<main>
			<div class="container">
				<div class="row-fluid">
					
				<div class="row-fluid">
					<div id="navigation" class="span3">
						<a href="https://itp.ifsp.edu.br/#" class="visible-phone visible-tablet mainmenu-toggle btn"><i
								class="icon-list"></i>&nbsp;Menu</a>
						<section id="navigation-section">
							<span class="hide">Início do menu principal</span>
							<h2 class="hide">Logo do Câmpus</h2>


							<div class="custom">
								<p><img src="assets/Artboard_1_copy_3.png"
										width="193" height="224"></p>
								<div id="ckimgrsz" style="left: 8px; top: 12px;">
									<div class="preview">&nbsp;</div>
								</div>
							</div>
							<nav class="menu-de-apoio span9">
								<h2 class="hide">Menu de Relevância </h2>

								<ul>
								<li class="item-263"><a href="https://itp.ifsp.edu.br/index.php/cursos">Cursos</a>
									</li>
									<li class="item-469"><a
											href="https://itp.ifsp.edu.br/index.php/manual-do-aluno">Manual do
											Estudante</a></li>
									<li class="item-525"><a
											href="https://itp.ifsp.edu.br/index.php/premios-e-destaques">Premios e
											Destaques</a></li>
											<br>
 <a><p style="text-align:start;color:#3C983A;background-color: #E5E5E5; 
height:50px; margin:0; line-height:24px;">ESPAÇO DE ACOLHIMENTO</p></a>
									
								<li class="item-263"><a href="loginsocio.html">Login <p>Sociopedagógico</p></a>
									</li>
											<?php
                                        if(isset($_SESSION["usuario"])){
                                            ?>
                                            <li class="item-263"><a href="denuncias.php">Denúncias</p></a></li>
                                            <li class="item-263"><a href="socios.php">Equipe Sociopedagógica</p></a></li>
											<li class="item-263"><a href="backend/sair.php">Sair</p></a></li>
                                            <?php
                                        }
                                    ?>
								</ul>
							</nav>			
						</section>
					</div>
					<div id="content" class="span9">
						<section id="content-section" class="fem">
							<h3 class="dados">Tratamento do Espaço de Acolhimento <br> IFSP - Itapetininga 
						Sociopedagógico</h3> <br>
						<p style = "font-size: 20px"> Este é um canal de acolhimento e auxílio para servir, 
										principalmente, ao público feminino da instituição, a fim de desenvolver um papel ativo na luta contra a 
										violação dos direitos das mulheres.</p>
						<p style = "font-size: 20px"> Neste contexto, o intuito é priorizar as questões de intolerância e violência de gênero e 
							proporcionar uma melhor experiência acadêmica às estudantes, tomando providências (que respeitem as vítimas em primeiro lugar) 
							cabíveis e efetivas. </p>
<br>
<div class="box" style="width: 730px; height: 131px; position: relative; padding-top: 25px;">
    <p>
        <a style="color: #1254B7; font-size: 23px; margin-left: 15px;" href="denuncias.php">Denúncias</a>
    </p>
    <p style="font-size: medium; margin-left: 15px;">Tratamento de denúncias.</p>
</div>


	 </div>
								
					
							</form>
							<span class="hide">Fim do conteúdo da página</span>
						</section>
					</div>
				</div>
			</div>
		</main>
		<footer>
			<div class="footer-atalhos">
				<div class="container">
					<div class="pull-right voltar-ao-topo"><a href="#portal-siteactions"><i class="fa-solid fa-chevron-up"></i>
						&nbsp;Voltar para o topo</a></div>
				</div>
			</div>
			<div class="container container-menus">
				<div id="footer" class="row footer-menus">
					<span class="hide">Início da navegação de rodapé</span>

					<div class="span3">
						<nav class="row assuntos nav">

							<h2>Consulte o cadastro do IFSP no e-MEC</h2>

							<ul>
								<li class="item-523"><a
										href="https://emec.mec.gov.br/emec/consulta-cadastro/detalhamento/d96957f455f6405d14c6542552b0f6eb/MTgxMA=="
										target="_blank" rel="noopener noreferrer"><img
											src="assets/qrcode_1810.png"
											alt="Consulte o cadastro do IFSP no e-MEC"></a></li>
							</ul>
						</nav>
					</div>


					<div class="span3">
						<nav class="row servicos nav">

							<h2>Serviços</h2>

							<ul>
								<li class="item-132 parent"><a
										href="https://itp.ifsp.edu.br/index.php/contato-e-localizacao">Contato </a></li>
								<li class="item-463"><a
										href="https://itp.ifsp.edu.br/index.php/localizacao">Localização</a></li>
								<li class="item-264"><a href="http://www.ifsp.edu.br/ouvidoria/" target="_blank"
										rel="noopener noreferrer">Ouvidoria</a></li>
								<li class="item-497"><a href="https://www.ifsp.edu.br/acessoainformacao" target="_blank"
										rel="noopener noreferrer">Acesso à Informação</a></li>
							</ul>
						</nav>
					</div>


					<div class="span3">
						<nav class="row redes-sociais nav">

							<h2>Redes Sociais</h2>

							<ul>
								<li class="item-138"><a href="https://www.facebook.com/ifspitape/" target="_blank"
										rel="noopener noreferrer">Facebook</a></li>
								<li class="item-257"><a href="https://www.instagram.com/ifspitapetininga/"
										target="_blank" rel="noopener noreferrer">Instagram</a></li>
								<li class="item-137"><a
										href="https://www.youtube.com/channel/UCEMUJSUnnvmrRQoD28-iGbQ/videos"
										target="_blank" rel="noopener noreferrer">YouTube</a></li>
							</ul>
						</nav>
					</div>


					<div class="span3">
						<nav class="row sobre nav">

							<h2>Sobre o site</h2>

							<ul>
								<li class="item-172"><a
										href="https://itp.ifsp.edu.br/index.php/acessibilidade">Acessibilidade</a></li>
								<li class="item-173"><a href="https://itp.ifsp.edu.br/index.php/mapa-do-site">Mapa do
										site</a></li>
							</ul>
						</nav>
					</div>
				</div>
			</div>
			<div class="footer-logos">
				<div class="container">
					<a href="http://www.acessoainformacao.gov.br/" class="logo-acesso pull-left"><img
							src="./Portal ITP - IFSP - Página inicial_files/acesso-a-informacao.png"
							alt="Acesso a Informação"></a>
				</div>
			</div>
			
			<div class="footer-atalhos visible-phone">
				<div class="container">
					<span class="hide">Fim do conteúdo da página</span>
					<div class="pull-right voltar-ao-topo"><a href="#portal-siteactions"><i
								class="icon-chevron-up"></i>&nbsp;Voltar para o topo</a></div>
				</div>
			</div>
		</footer>
	</div>
	
</body>

</html>