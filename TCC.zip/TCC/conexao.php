<?php

$dbHost = 'localhost';
$dbUsername = 'root';
$dbPassword = '';
$dbName = 'tcc';

$conexao = mysqli_connect($dbHost,$dbUsername,$dbPassword,$dbName);

