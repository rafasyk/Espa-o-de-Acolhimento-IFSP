CREATE DATABASE IF NOT EXISTS tcc;

USE tcc;

CREATE TABLE IF NOT EXISTS denuncias (
  id int NOT NULL,
  texto text NOT NULL,
  prontuario VARCHAR(50) NOT NULL,
  nomeAluno VARCHAR(255),
  Ano VARCHAR(50),
  Parecer text,
  Aprovado BIT NOT NULL,
  PRIMARY KEY (id)
);

CREATE TABLE IF NOT EXISTS socio (
  id int NOT NULL AUTO_INCREMENT,
  nome varchar(50) NOT NULL,
  photo varchar(100) NOT NULL,
  password varchar(255) NOT NULL,
  PRIMARY KEY (id)
);